package models

type Course struct {
	ID       int
	Name     string
	MaxQuota int
}
