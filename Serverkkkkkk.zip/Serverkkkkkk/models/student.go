package models

type Student struct {
	ID    int
	Name  string
	Email string
}
