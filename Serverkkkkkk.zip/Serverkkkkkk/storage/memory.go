package storage

import (
	"academic-enrollments/models"
	"time"
)

var Students = []models.Student{
	{ID: 1, Name: "Juan", Email: "juan@mail.com"},
	{ID: 2, Name: "Maria", Email: "maria@mail.com"},
	{ID: 3, Name: "Ana", Email: "ana@mail.com"},
}

var Courses = []models.Course{
	{ID: 1, Name: "Go", MaxQuota: 2},
	{ID: 2, Name: "Bases de Datos", MaxQuota: 3},
	{ID: 3, Name: "Redes", MaxQuota: 2},
}

var Enrollments = []models.Enrollment{
	{ID: 1, StudentID: 1, CourseID: 1, Amount: 100, Status: "pagado", Date: time.Now()},
	{ID: 2, StudentID: 2, CourseID: 1, Amount: 100, Status: "pendiente", Date: time.Now()},
	{ID: 3, StudentID: 3, CourseID: 2, Amount: 120, Status: "pagado", Date: time.Now()},
}
var NextID = 4
