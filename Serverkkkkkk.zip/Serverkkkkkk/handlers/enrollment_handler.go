package handlers

import (
	"academic-enrollments/models"
	"academic-enrollments/storage"
	"encoding/json"
	"net/http"
	"strconv"
	"strings"
	"time"
)

func errorJSON(w http.ResponseWriter, msg string, code int) {
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(map[string]string{"error": msg})
}

func EnrollmentsHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method == "GET" {
		json.NewEncoder(w).Encode(storage.Enrollments)
		return
	}

	if r.Method == "POST" {
		var e models.Enrollment

		if err := json.NewDecoder(r.Body).Decode(&e); err != nil {
			errorJSON(w, "Datos inválidos", 400)
			return
		}

		studentOK := false
		for _, s := range storage.Students {
			if s.ID == e.StudentID {
				studentOK = true
			}
		}
		if !studentOK {
			errorJSON(w, "Estudiante no existe", 400)
			return
		}

		courseOK := false
		maxQuota := 0

		for _, c := range storage.Courses {
			if c.ID == e.CourseID {
				courseOK = true
				maxQuota = c.MaxQuota
			}
		}
		if !courseOK {
			errorJSON(w, "Curso no existe", 400)
			return
		}

		used := 0
		for _, m := range storage.Enrollments {
			if m.CourseID == e.CourseID {
				used++
			}
		}
		if used >= maxQuota {
			errorJSON(w, "Curso lleno", 409)
			return
		}

		if e.Amount <= 0 {
			errorJSON(w, "Monto inválido", 400)
			return
		}

		if e.Status != "pagado" && e.Status != "pendiente" {
			errorJSON(w, "Estado inválido", 400)
			return
		}

		e.ID = storage.NextID
		storage.NextID++
		e.Date = time.Now()

		storage.Enrollments = append(storage.Enrollments, e)

		w.WriteHeader(201)
		json.NewEncoder(w).Encode(e)
	}
}

func EnrollmentHandler(w http.ResponseWriter, r *http.Request) {

	idStr := strings.TrimPrefix(r.URL.Path, "/enrollments/")
	id, _ := strconv.Atoi(idStr)

	for i, e := range storage.Enrollments {

		if e.ID == id {

			if r.Method == "GET" {
				json.NewEncoder(w).Encode(e)
				return
			}

			if r.Method == "PUT" {
				var input models.Enrollment
				json.NewDecoder(r.Body).Decode(&input)

				if input.Status != "pagado" && input.Status != "pendiente" {
					errorJSON(w, "Estado inválido", 400)
					return
				}

				storage.Enrollments[i].Status = input.Status
				json.NewEncoder(w).Encode(storage.Enrollments[i])
				return
			}

			if r.Method == "DELETE" {
				storage.Enrollments = append(
					storage.Enrollments[:i],
					storage.Enrollments[i+1:]...,
				)
				w.WriteHeader(204)
				return
			}
		}
	}

	errorJSON(w, "Matrícula no encontrada", 404)
}
